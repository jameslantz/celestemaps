cat << EOF
<EmbeddedResource Include="$1">
  <LogicalName>$1</LogicalName>
</EmbeddedResource>
EOF
