#!/usr/bin/env bash
source $stdenv/setup
$nuget restore
