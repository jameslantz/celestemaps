The versions here are versions stripped with mono-cil-strip.

# DON'T PUSH THE ORIGINAL VERSION OF THE STRIPPED LIBS!

Feel free to replace the .dlls **locally** though.
